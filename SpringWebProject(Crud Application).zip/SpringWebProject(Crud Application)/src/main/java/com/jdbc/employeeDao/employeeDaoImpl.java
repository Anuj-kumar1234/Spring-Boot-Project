package com.jdbc.employeeDao;

import java.util.List;
import com.jdbc.repository.EmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jdbc.model.Employee;


@Service

public class employeeDaoImpl implements employeeDao {
	
	@Autowired
	EmployeeRepository employeeR;

	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
		employeeR.save(emp);
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		List<Employee> employeeList = employeeR.findAll();
		return employeeList;
	}

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		Employee employee=employeeR.getById(id);
		return employee;
		
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeR.save(emp);
		
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		employeeR.deleteById(id);
	}

	@Override
	public Employee validateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		Employee employee1=employeeR.findByLoginData(emp.getId(),emp.getPassword());
		return employee1;
	}
	

}
