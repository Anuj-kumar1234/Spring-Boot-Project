package com.jdbc.employeeDao;
import java.util.List;

import org.springframework.stereotype.Service;

import com.jdbc.model.*;

@Service
public interface employeeDao {
 public void addEmployee(Employee emp);
 public List<Employee> getAllEmployee();
 public Employee getEmployeeById(int id);
 public void updateEmployee(Employee emp);
 public void deleteEmployee(int id);
 public Employee validateEmployee(Employee emp);
 
 
 
}
